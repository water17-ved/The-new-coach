# JEE Coach — Native Android

A native Kotlin + Jetpack Compose JEE execution coach.

## Current version

- Native Android UI
- Gemini REST integration
- JSON import/export
- Local-only preparation state
- Natural-language "Ask Coach"
- Visible staged AI-processing progress bar (without exposing private chain-of-thought)
- Mission card
- JEE-specific strategy rules
- GitHub Actions debug APK build

## Gemini setup

Open **Settings → Gemini API** and enter your own Gemini API key.

The key is intentionally NOT embedded in the source code or APK.

## JSON example

```json
{
  "exam": "JEE Advanced",
  "date": "2027-05-01",
  "pending_tasks": [
    "Complete Electrostatics PYQs",
    "Finish Integration"
  ],
  "recent_performance": {
    "mock_score": 142
  }
}
```

The schema is intentionally extensible. The next development stage should add structured syllabus, chapter mastery, PYQ counts, test attempts, errors, study history and execution history.

## Build

GitHub Actions builds `app-debug.apk` automatically.

For local build, install Android Studio/JDK 17 and run:

```bash
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
```
