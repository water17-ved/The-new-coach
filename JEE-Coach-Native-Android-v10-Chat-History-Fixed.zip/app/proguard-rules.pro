# Keep Compose
-keep class androidx.compose.** { *; }
-keep class kotlin.** { *; }
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable

# Keep app classes
-keep class com.jeecoach.app.** { *; }

# Kotlin serialization
-keepclassmembers class * {
    @kotlinx.serialization.SerialName <fields>;
}
