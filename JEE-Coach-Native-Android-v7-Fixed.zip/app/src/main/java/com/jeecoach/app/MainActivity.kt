package com.jeecoach.app

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val PREFS = "jee_coach_state"
private const val KEY_STATE = "state"

data class Mission(val title: String, val duration: Int, val reason: String, val status: String = "PENDING")
data class ChatMessage(val role: String, val text: String, val time: Long = System.currentTimeMillis())
data class Chat(val id: String, var title: String, val messages: MutableList<ChatMessage>, var updated: Long = System.currentTimeMillis())

class CoachViewModel(private val appContext: Context) : ViewModel() {
    var apiKey by mutableStateOf("")
    var coachMessage by mutableStateOf("Tell me what is happening. I will decide the highest-value next action.")
    var currentMission by mutableStateOf(Mission("Import your preparation data", 20, "The coach needs your real state before making a plan."))
    var loading by mutableStateOf(false)
    var progress by mutableStateOf(0)
    var progressStage by mutableStateOf("")
    var error by mutableStateOf<String?>(null)
    var behavior by mutableStateOf("Be strict but fair. Don't let me postpone difficult chapters repeatedly. Keep plans realistic. Prefer JEE Advanced quality, but never overload me. Praise real progress, not intentions. If I waste time, make a practical recovery plan. Always tell me the single highest-value next action and explain why.")
    var memory by mutableStateOf("No persistent JEE memory yet. Import your preparation or tell the coach important facts about your preparation.")
    var jsonState by mutableStateOf("{}")
    var chats by mutableStateOf(listOf<Chat>())
    var activeChatId by mutableStateOf("")

    init { load() }

    private fun load() {
        val raw = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_STATE, null) ?: return
        try {
            val o = JSONObject(raw)
            apiKey = o.optString("apiKey", "")
            behavior = o.optString("behavior", behavior)
            memory = o.optString("memory", memory)
            jsonState = o.optString("jsonState", "{}")
            val arr = o.optJSONArray("chats") ?: JSONArray()
            val list = mutableListOf<Chat>()
            for (i in 0 until arr.length()) {
                val c = arr.getJSONObject(i)
                val msgs = mutableListOf<ChatMessage>()
                val ma = c.optJSONArray("messages") ?: JSONArray()
                for (j in 0 until ma.length()) {
                    val m = ma.getJSONObject(j)
                    msgs += ChatMessage(m.optString("role"), m.optString("text"), m.optLong("time"))
                }
                list += Chat(c.optString("id"), c.optString("title", "New chat"), msgs, c.optLong("updated"))
            }
            chats = list
            activeChatId = o.optString("activeChatId", "")
            if (chats.isEmpty()) newChat(false)
            else if (activeChatId.isBlank() || chats.none { it.id == activeChatId }) activeChatId = chats.first().id
        } catch (_: Exception) { newChat(false) }
    }

    private fun save() {
        val o = JSONObject().apply {
            put("version", 2); put("savedAt", System.currentTimeMillis())
            put("apiKey", apiKey); put("behavior", behavior); put("memory", memory); put("jsonState", jsonState); put("activeChatId", activeChatId)
            put("chats", JSONArray().apply { chats.forEach { c -> put(JSONObject().apply { put("id", c.id); put("title", c.title); put("updated", c.updated); put("messages", JSONArray().apply { c.messages.forEach { m -> put(JSONObject().apply { put("role", m.role); put("text", m.text); put("time", m.time) }) } }) }) } })
        }
        appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_STATE, o.toString()).apply()
    }

    fun newChat(confirmless: Boolean = true) {
        val id = System.currentTimeMillis().toString()
        val c = Chat(id, "New chat", mutableListOf())
        chats = listOf(c) + chats
        activeChatId = id
        save()
    }

    fun activeChat(): Chat? = chats.firstOrNull { it.id == activeChatId }

    fun selectChat(id: String) { activeChatId = id; save() }

    fun importJson(text: String) {
        try {
            val obj = JSONObject(text)
            jsonState = obj.toString(2)
            val pending = obj.optJSONArray("pending_tasks")
            if (pending != null && pending.length() > 0) currentMission = Mission(pending.optString(0), 45, "This is the first declared pending task. I will refine priority using your full state.")
            memory = buildMemory(obj)
            coachMessage = "Preparation state imported. I also updated persistent coach memory from the data."
            error = null; save()
        } catch (e: Exception) { error = "Invalid JSON: ${e.message}" }
    }

    private fun buildMemory(o: JSONObject): String {
        val out = mutableListOf<String>()
        if (o.has("exam")) out += "Exam: ${o.optString("exam")}"
        if (o.has("date")) out += "Target date: ${o.optString("date")}"
        if (o.has("recent_performance")) out += "Recent performance: ${o.optJSONObject("recent_performance")?.toString(2)}"
        if (o.has("pending_tasks")) out += "Pending tasks: ${o.optJSONArray("pending_tasks")?.toString()}"
        if (o.has("subjects")) out += "Syllabus/progress: ${o.optJSONObject("subjects")?.toString(2)}"
        return if (out.isEmpty()) memory else out.joinToString("\n")
    }

    fun updateBehavior(text: String) { behavior = text; save() }
    fun updateApiKey(text: String) { apiKey = text; save() }

    fun exportJson(context: Context, uri: Uri) {
        try { context.contentResolver.openOutputStream(uri)?.use { it.write(buildExport().toString(2).toByteArray()) }; error = null }
        catch (e: Exception) { error = "Export failed: ${e.message}" }
    }

    fun buildExport(): JSONObject = JSONObject().apply {
        put("app", "JEE Coach"); put("version", 2); put("exportedAt", System.currentTimeMillis())
        put("behavior", behavior); put("memory", memory); put("preparationState", JSONObject(jsonState)); put("activeChatId", activeChatId)
        put("chats", JSONArray().apply { chats.forEach { c -> put(JSONObject().apply { put("id", c.id); put("title", c.title); put("updated", c.updated); put("messages", JSONArray().apply { c.messages.forEach { m -> put(JSONObject().apply { put("role", m.role); put("text", m.text); put("time", m.time) }) } }) }) } })
    }

    fun addUserMessage(text: String) {
        val c = activeChat() ?: return
        if (c.title == "New chat") c.title = text.trim().take(34).ifBlank { "Chat" }
        c.messages += ChatMessage("user", text); c.updated = System.currentTimeMillis(); chats = chats.toList(); save()
    }

    fun addAssistantMessage(text: String) {
        val c = activeChat() ?: return
        c.messages += ChatMessage("assistant", text); c.updated = System.currentTimeMillis(); chats = chats.toList(); save(); coachMessage = text
    }

    suspend fun askGemini(userCommand: String) {
        if (apiKey.isBlank()) { error = "Add your Gemini API key in Settings first."; return }
        addUserMessage(userCommand); loading = true; progress = 5; progressStage = "Understanding your request"; error = null
        val history = activeChat()?.messages?.takeLast(12)?.joinToString("\n") { "${it.role.uppercase()}: ${it.text}" } ?: ""
        val system = """
You are JEE Coach, an execution coach for JEE Main/Advanced.
Write like a normal high-quality AI assistant. Use Markdown naturally: **bold**, *italics*, emojis, bullets, numbered steps, quotes, and Markdown tables when useful. If numerical progress or trends genuinely benefit from a graph, provide a compact text chart or explain the chart data; never force a graph.
Never expose private chain-of-thought. The app may show high-level processing stages only.
Use the student's persistent memory and preparation state. Do not invent facts.
Behaviour profile chosen by the student:
$behavior
Persistent JEE memory:
$memory
Preparation JSON:
$jsonState
Recent conversation:
$history

Core coaching rules: no shame; no giant unrealistic timetables; define completion; active problems/PYQs/errors/testing generally beat passive watching; diagnose repeated avoidance; praise evidence-backed progress; always give the single highest-value next action and explain WHY. Use NOW -> NEXT -> AFTER THAT when planning.
User message: $userCommand
""".trimIndent()
        try {
            delay(180); progress = 22; progressStage = "Reading your preparation state"
            delay(180); progress = 38; progressStage = "Checking strategy and priorities"
            delay(180); progress = 56; progressStage = "Generating a practical recommendation"
            val answer = gemini(system, apiKey)
            progress = 78; progressStage = "Checking feasibility against your behaviour profile"
            delay(220); progress = 94; progressStage = "Preparing the response"
            addAssistantMessage(answer); progress = 100; progressStage = "Complete"
        } catch (e: Exception) { error = "Gemini request failed: ${e.message}"; progressStage = "Request failed" }
        finally { loading = false }
    }

    private suspend fun gemini(prompt: String, key: String): String = withContext(Dispatchers.IO) {
        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key"
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt))))).toString()
        val conn = URL(endpoint).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"; conn.setRequestProperty("Content-Type", "application/json"); conn.doOutput = true; conn.connectTimeout = 20000; conn.readTimeout = 30000
        conn.outputStream.use { it.write(body.toByteArray()) }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        if (conn.responseCode !in 200..299) throw Exception(response.take(500))
        JSONObject(response).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")?.takeIf { it.isNotBlank() } ?: "Gemini returned no text."
    }
}

class CoachFactory(private val context: Context) : androidx.lifecycle.ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T = CoachViewModel(context.applicationContext) as T
}

@Composable fun JEECoachApp(context: Context) {
    val vm: CoachViewModel = viewModel(factory = CoachFactory(context))
    var tab by remember { mutableStateOf(0) }
    var command by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { context.contentResolver.openInputStream(it)?.bufferedReader()?.use { r -> vm.importJson(r.readText()) } } }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri -> if (uri != null) vm.exportJson(context, uri) }
    val colors = darkColorScheme(primary = Color(0xFF7CDBFF), secondary = Color(0xFFA88BFF), background = Color(0xFF090D12), surface = Color(0xFF121821))
    MaterialTheme(colorScheme = colors) {
        Scaffold(containerColor = colors.background, bottomBar = {
            NavigationBar(containerColor = Color(0xFF0E141C)) {
                listOf("Coach" to Icons.Default.Home, "Chat" to Icons.Default.Chat, "Mission" to Icons.Default.CheckCircle, "History" to Icons.Default.History, "Settings" to Icons.Default.Settings).forEachIndexed { i, p ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(p.second, null) }, label = { Text(p.first) })
                }
            }
        }) { pad ->
            when (tab) {
                0 -> HomeScreen(vm, command, { command = it }, { scope.launch { vm.askGemini(command); command = "" } }, importLauncher, exportLauncher, pad)
                1 -> ChatScreen(vm, { scope.launch { vm.askGemini(it) } }, pad)
                2 -> MissionScreen(vm, pad)
                3 -> HistoryScreen(vm, pad)
                4 -> SettingsScreen(vm, importLauncher, exportLauncher, pad)
            }
        }
    }
}

@Composable fun CardBox(content: @Composable ColumnScope.() -> Unit) { Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Color(0xFF121821)), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(18.dp), content = content) } }

@Composable fun HomeScreen(vm: CoachViewModel, command: String, onCommand: (String) -> Unit, ask: () -> Unit, importLauncher: androidx.activity.result.ActivityResultLauncher<Array<String>>, exportLauncher: androidx.activity.result.ActivityResultLauncher<String>, pad: PaddingValues) {
    LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("JEE COACH", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("Your preparation. Your reality. One next action.", color = Color.LightGray) }
        item { CardBox { Text("NEXT MISSION", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text(vm.currentMission.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text("${vm.currentMission.duration} minutes"); Spacer(Modifier.height(8.dp)); Text("WHY: ${vm.currentMission.reason}", color = Color.LightGray); Spacer(Modifier.height(12.dp)); Button(
                    onClick = { ask() },
                    enabled = !vm.loading && command.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (vm.loading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp)
                        )
                    } else {
                        Text("ASK COACH")
                    }
                } } }
        item { CardBox { Text("ASK COACH", fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); OutlinedTextField(command, onCommand, Modifier.fillMaxWidth(), placeholder = { Text("I wasted 3 hours. I have 5 hours left. Fix today.") }, minLines = 3); Spacer(Modifier.height(10.dp)); Button(onClick = ask, enabled = !vm.loading && command.isNotBlank(), modifier = Modifier.fillMaxWidth()) { if (vm.loading) CircularProgressIndicator(Modifier.size(18.dp)) else Text("ASK COACH") }; ProgressPanel(vm); Spacer(Modifier.height(10.dp)); MarkdownText(vm.coachMessage) } }
        item { CardBox { Text("PERSISTENT MEMORY", fontWeight = FontWeight.Bold); Spacer(Modifier.height(7.dp)); Text(vm.memory.take(500), color = Color.LightGray); Spacer(Modifier.height(8.dp)); Text("Memory is carried into future chats and exported with your state.", style = MaterialTheme.typography.bodySmall, color = Color.Gray) } }
        item { CardBox { Text("PORTABLE STATE", fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button({ importLauncher.launch(arrayOf("application/json")) }, Modifier.weight(1f)) { Text("IMPORT JSON") }; OutlinedButton({ exportLauncher.launch("jee-coach-state.json") }, Modifier.weight(1f)) { Text("EXPORT") } } } }
        vm.error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
    }
}

@Composable fun ProgressPanel(vm: CoachViewModel) { if (vm.loading || vm.progress > 0) { Spacer(Modifier.height(12.dp)); LinearProgressIndicator({ vm.progress / 100f }, Modifier.fillMaxWidth().height(7.dp)); Row(Modifier.fillMaxWidth().padding(top = 6.dp), Arrangement.SpaceBetween) { Text(vm.progressStage, color = Color.LightGray); Text("${vm.progress}%", fontWeight = FontWeight.Bold) }; Text("High-level app processing status — not Gemini's private reasoning.", style = MaterialTheme.typography.bodySmall, color = Color.Gray) } }

@Composable fun ChatScreen(vm: CoachViewModel, ask: (String) -> Unit, pad: PaddingValues) {
    var text by remember { mutableStateOf("") }
    var showNew by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(pad)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) { Text(vm.activeChat()?.title ?: "Chat", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); TextButton({ showNew = true }) { Text("New Chat") } }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            val msgs = vm.activeChat()?.messages ?: emptyList()
            items(msgs) { m -> MessageBubble(m) }
            if (vm.loading) item { CardBox { Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(18.dp)); Spacer(Modifier.width(10.dp)); Text(vm.progressStage.ifBlank { "Thinking…" }) } } }
        }
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.Bottom) { OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("Ask anything about your preparation…") }); Spacer(Modifier.width(8.dp)); IconButton(onClick = { if (text.isNotBlank() && !vm.loading) { val t = text.trim(); text = ""; ask(t) } }) { Icon(Icons.Default.Send, "Send") } }
    }
    if (showNew) AlertDialog(onDismissRequest = { showNew = false }, title = { Text("Start a new chat?") }, text = { Text("Your old chats stay saved in History. This only starts a separate conversation.") }, confirmButton = { TextButton({ vm.newChat(); showNew = false }) { Text("New chat") } }, dismissButton = { TextButton({ showNew = false }) { Text("Cancel") } })
}

@Composable fun MessageBubble(m: ChatMessage) { val user = m.role == "user"; Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) { Surface(shape = RoundedCornerShape(16.dp), color = if (user) Color(0xFF1B2A36) else Color(0xFF121821), modifier = Modifier.widthIn(max = 360.dp)) { Column(Modifier.padding(13.dp)) { if (!user) Text("JEE COACH", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold); MarkdownText(m.text) } } } }

@Composable fun MarkdownText(text: String) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        text.split("\n").forEach { line ->
            when {
                line.trim().startsWith("|") -> Text(line.replace("|", "  ").trim(), color = Color.LightGray)
                line.trim().startsWith("###") -> Text(line.replaceFirst("###", "").trim(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                line.trim().startsWith("##") -> Text(line.replaceFirst("##", "").trim(), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                line.trim().startsWith("#") -> Text(line.replaceFirst("#", "").trim(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                line.trim().startsWith("- ") || line.trim().startsWith("* ") -> Text("• " + line.trim().drop(2), color = Color.LightGray)
                line.trim().matches(Regex("\\d+\\. .*")) -> Text(line.trim(), color = Color.LightGray)
                line.isBlank() -> Spacer(Modifier.height(2.dp))
                else -> Text(styledMarkdown(line))
            }
        }
    }
}

private fun styledMarkdown(s: String): AnnotatedString = buildAnnotatedString {
    var i = 0
    val regex = Regex("(\\*\\*.*?\\*\\*)|(\\*.*?\\*)")
    regex.findAll(s).forEach { match ->
        append(s.substring(i, match.range.first))
        val raw = match.value
        val content = raw.removePrefix("**").removeSuffix("**").removePrefix("*").removeSuffix("*")
        withStyle(SpanStyle(fontWeight = if (raw.startsWith("**")) FontWeight.Bold else FontWeight.Normal, fontStyle = if (raw.startsWith("*") && !raw.startsWith("**")) androidx.compose.ui.text.font.FontStyle.Italic else androidx.compose.ui.text.font.FontStyle.Normal)) { append(content) }
        i = match.range.last + 1
    }
    append(s.substring(i))
}

@Composable fun MissionScreen(vm: CoachViewModel, pad: PaddingValues) { Column(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) { Text("MISSION", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); CardBox { Text(vm.currentMission.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text("${vm.currentMission.duration} min • ${vm.currentMission.status}"); Spacer(Modifier.height(8.dp)); Text(vm.currentMission.reason, color = Color.LightGray); Spacer(Modifier.height(14.dp)); Button({}, Modifier.fillMaxWidth()) { Text("START") }; OutlinedButton({}, Modifier.fillMaxWidth()) { Text("MARK COMPLETE") } } } }

@Composable fun HistoryScreen(vm: CoachViewModel, pad: PaddingValues) { Column(Modifier.fillMaxSize().padding(pad)) { Row(Modifier.fillMaxWidth().padding(16.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) { Column { Text("CHAT HISTORY", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("Your old conversations remain accessible.", color = Color.Gray) }; Text("${vm.chats.size}") }; LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { items(vm.chats) { c -> CardBox { Column(Modifier.fillMaxWidth().clickable { vm.selectChat(c.id) }) { Text(c.title, fontWeight = FontWeight.Bold); Text("${c.messages.size} messages • ${SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(c.updated))}", color = Color.Gray); c.messages.lastOrNull()?.let { Text(if (it.role == "user") "You: ${it.text}" else "Coach: ${it.text}", color = Color.LightGray, maxLines = 2) } } } } } } }

@Composable fun SettingsScreen(vm: CoachViewModel, importLauncher: androidx.activity.result.ActivityResultLauncher<Array<String>>, exportLauncher: androidx.activity.result.ActivityResultLauncher<String>, pad: PaddingValues) { var b by remember(vm.behavior) { mutableStateOf(vm.behavior) }; Column(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) { Text("SETTINGS", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); CardBox { Text("HOW SHOULD YOUR AI BEHAVE?", fontWeight = FontWeight.Bold); Spacer(Modifier.height(7.dp)); Text("Describe it naturally. The coach uses this across chats, planning, missions and recommendations.", color = Color.Gray); Spacer(Modifier.height(9.dp)); OutlinedTextField(b, { b = it }, Modifier.fillMaxWidth(), minLines = 6); Spacer(Modifier.height(8.dp)); Button({ vm.updateBehavior(b) }, Modifier.fillMaxWidth()) { Text("APPLY BEHAVIOUR") } }; CardBox { Text("PERSISTENT MEMORY", fontWeight = FontWeight.Bold); Spacer(Modifier.height(7.dp)); Text(vm.memory, color = Color.LightGray); Spacer(Modifier.height(8.dp)); Text("Memory is stored locally with the app state and included in exports.", style = MaterialTheme.typography.bodySmall, color = Color.Gray) }; CardBox { Text("GEMINI", fontWeight = FontWeight.Bold); Spacer(Modifier.height(7.dp)); OutlinedTextField(vm.apiKey, { vm.updateApiKey(it) }, Modifier.fillMaxWidth(), label = { Text("Gemini API key") }, singleLine = true); Text("Your key is entered locally; it is not hard-coded into the source.", color = Color.Gray, style = MaterialTheme.typography.bodySmall) }; CardBox { Text("DATA", fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button({ importLauncher.launch(arrayOf("application/json")) }, Modifier.weight(1f)) { Text("IMPORT") }; OutlinedButton({ exportLauncher.launch("jee-coach-state.json") }, Modifier.weight(1f)) { Text("EXPORT") } } } } }
